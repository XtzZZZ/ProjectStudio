from django.contrib import admin
from django.urls import path

from .views import *

urlpatterns = [
    path('', HomePageRender, name='Home'),
    path('Subject/<int:SubjectName>/', SubjectFilter, name='Subject'),
    path('OfferProject/', OfferProject, name = 'OfferProject' ),
    path('Login/', Login, name='Login'),
    path('Logout/', Logout, name='Logout'),
    path('Register/', Register, name='Register'),
    path('SearchProject/', ProjectSearch, name='SearchProject'),
    path('CreateProject/', ProjectCreate, name='CreateProject'),
    path('Project/<int:ProjectId>/', SingleProject ,name='Project'),
    path('Project/Change/<int:ProjectId>/', ChangeProject, name='ChangeProject'),
    path('MyProjects/', MyProjects, name='MyProjects'),
    path('Project/<int:ProjectId>/ApplyProject/', ApplyProject, name='ApplyProject'),
    path('Project/<int:ProjectId>/TaskCreate/', SingleProject , name='TaskCreate'),
    path('Task/<int:TaskId>', TaskDone, name='TaskDone'),
    path('CancelProject/<int:ProjectId>',  CancelProject, name='CancelProject'),
    path('ClearTasks/<int:ProjectId>', ClearTasks, name='ClearTasks'),
    path('ProjectDone/<int:ProjectId>', ProjectDone, name='ProjectDone'),
    path('ProjectResume/<int:ProjectId>', ProjectResume, name='ProjectResume')
]    
