
from django.core.files.storage import FileSystemStorage
from django.db import models
from django.db.models.expressions import Value
from django.db.models.fields import CharField
from django.db.models.fields.related import ForeignKey
from django.contrib.auth.models import User
import os

from Sch.settings import BASE_DIR, STATIC_URL
fs=FileSystemStorage(location='/Project Files')

class Subject(models.Model):
    SubjectName = models.CharField(verbose_name='Название предмета', max_length=150)
    
    class Meta:
        verbose_name = 'Предмет'
        verbose_name_plural = 'Предметы'

    def __str__(self) -> str:
        return self.SubjectName

class Project(models.Model):
    ProjectName = models.CharField(verbose_name='Название проекта', max_length=150)
    Subject = models.ForeignKey('Subject', verbose_name='Предмет', on_delete=models.CASCADE)
    Summury = models.TextField('Краткое описание', blank=True)
    Content = models.TextField(verbose_name='Описание проекта')
    CreatedAt = models.DateField(auto_now_add=True, verbose_name='Дата создания')
    Author = models.ForeignKey(User,verbose_name='Автор', blank=True, on_delete=models.SET_NULL, null=True)
    Users = models.ManyToManyField(User, blank=True, related_name='Team', related_query_name='Team')

    OptionsForStatus = [
        ('published', 'Опубликовано'),
        ('offered', 'Предложено'),
        ('processing', 'Выполняется'),
        ('done', 'Готово')
    ]
    Status = models.CharField(verbose_name='Статус', choices=OptionsForStatus, default='offered', max_length=40)

    class Meta:
        verbose_name = 'Проект'
        verbose_name_plural = 'Проекты'
    
    
    def __str__(self) -> str:
        return self.ProjectName

class Task(models.Model):
    TaskName = models.CharField(verbose_name='Задача', max_length=200, )
    Content = models.TextField(verbose_name='Описание')
    ProjectRel = models.ForeignKey('Project', on_delete=models.CASCADE, verbose_name='Проект')
    Done = models.BooleanField(verbose_name='Выполнено')
    CreatedAt = models.DateField(verbose_name='Дата создания',auto_now_add=True)
    DateTo = models.DateField(verbose_name='Выполнить к')
    
    
    class Meta:
        verbose_name = 'Задача'
        verbose_name_plural = 'Задачи'
        ordering = ['DateTo']
    
    def __str__(self) -> str:
        return self.TaskName



class UserProfile(models.Model):
    
    Project = models.ManyToManyField(Project, blank=True)
    User = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Пользователь', null=True)

    def __str__(self) -> str:
        return self.User.username

    

    class Meta:
        verbose_name= 'Профиль'
        verbose_name_plural= 'Профили'

class ProjectFile(models.Model):
    File = models.FileField('Файл', null=True)
    Project = models.ForeignKey(Project, models.CASCADE, verbose_name='Проект', null=True)
    
    def __str__(self) -> str:
        return self.Name

    class Meta:
        verbose_name = 'Файл'
        verbose_name_plural = 'Файлы'