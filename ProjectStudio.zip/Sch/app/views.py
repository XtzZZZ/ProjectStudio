from distutils.command.clean import clean
from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import *
from .forms import OfferProject as of
#from . import forms
from .forms import *
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.core.paginator import Paginator
from django.utils.encoding import smart_str 
from django.db.models import Q

def ASCII(S):
    return smart_str(S, 'ascii')

def HomePageRender(request):
    Projects = Project.objects.filter(Status = 'published')
    paginator = Paginator(Projects, 12)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)
    Subjects = Subject.objects.all()
    return render( request, 'app/HomePage.html', {'page_obj': page_obj, 'subjects': Subjects } )

def SubjectFilter(request,SubjectName):
    Projects = Project.objects.filter(Status = 'published', Subject = SubjectName)
    paginator = Paginator(Projects, 12)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)
    Subjects = Subject.objects.all()
    return render( request, 'app/HomePage.html', {'page_obj': page_obj, 'subjects': Subjects } )

def OfferProject(request):
    if request.method == 'POST':
        form = of(request.POST)
        if form.is_valid():
            data={
                'ProjectName': form.cleaned_data['ProjectName'],
                'Subject':form.cleaned_data['Subject'],
                'Summury': form.cleaned_data['Summury'],
                'Content':form.cleaned_data['Content'],
                'Author': request.user
            }
            Project.objects.create(**data)
        return redirect('Home')
    else:
        form = of()
        form2 = UplodeFileForm()
    return render(request, 'app/OfferProject.html', {'form': form, 'form2': form2})

def Register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            if form.cleaned_data['password1']==form.cleaned_data['password2']:
                user = form.save()
                login(request, user)
                messages.success(request, 'Вы успешно зарегистрировались')
                return redirect('Login')
            else:
                messages.error(request, 'Ошибка регистрации')
        else:
            messages.error(request, 'Ошибка регистрации')
    else:
        form = UserRegisterForm()
    return render(request, 'app/Register.html', {'form': form})

def Login(request):
    if request.method == 'POST':
        form = UserLoginForm(data=request.POST)
        if form.is_valid():
            user=form.get_user()
            login(request, user)
            messages.success(request, 'Вы успешно вошли')
            return redirect('Home')
        else:
            messages.error(request, 'Ошибка входа')
    else:
        form = UserLoginForm()
    return render(request, 'app/Login.html',  {'form':form})

def Logout(request):
    logout(request)
    return redirect('Login')

def ProjectSearch(request):
    if request.method == 'POST':
        form = SearchProjects(request.POST)
        
        if form.is_valid():
            
            inmyprojects = form.cleaned_data['InMyProjects']
            inproject = form.cleaned_data['InProject'].split()
            Project = list()
            if form.cleaned_data['Subject']==None:
                subject = Subject.objects.all()
            else:
                subject=[form.cleaned_data['Subject']]
            if inproject != []:
                if inmyprojects:
                    for i in inproject:
                        a = md.Project.objects.filter(Q(ProjectName__icontains= i) | Q(Summury__icontains = i) | Q(Content__icontains= i), Subject__in= subject, Users=request.user)
                        Project.append(a)
                else:
                    print(subject, inproject) 
                    for i in inproject:
                        
                        a = md.Project.objects.filter(Q(ProjectName__icontains= i) | Q(Summury__icontains = i) | Q(Content__icontains= i) , Subject__in= subject, Status='published')
                        Project.append(a)
            else:
                if inmyprojects:
                    Project= [md.Project.objects.filter(Subject__in= subject, Users=request.user)]
                else:
                    Project= [md.Project.objects.filter(Subject__in= subject, Status='published')]
            print(Project)
            

            return render( request, 'app/searchresult.html', {'projects':Project} )
    else:
        form = SearchProjects()
        return render(request, 'app/SearchProject.html', {'form': form}) 

def ProjectCreate(request):
    if request.method == 'POST':
        form = CreateProject(request.POST)
        if form.is_valid():
            data={
                'ProjectName': form.cleaned_data['ProjectName'],
                'Subject':form.cleaned_data['Subject'],
                'Summury': form.cleaned_data['Summury'],
                'Content':form.cleaned_data['Content'],
                'Author': request.user,
                'Status': 'processing',
            }
            Project.objects.create(**data)
            prj= Project.objects.get(ProjectName = data['ProjectName'])
            for user in form.cleaned_data['Users'].split():
                print(user)
                prj.Users.add(User.objects.get(username=user))
            return redirect('Home')
    else:
        form = CreateProject()
        form2 = UplodeFileForm()
    return render(request, 'app/CreateProject.html', {'form': form , 'form2': form2})

def UserList(Project):
    users = Project.Users.all()
    userslist = list()
    for i in users:
        print(i.username)
        userslist.append(i.username)
    return userslist

def SingleProject(request, ProjectId):
    Project = md.Project.objects.get(pk=ProjectId)
    print(Project.Users.all(), Project.ProjectName)
    print((request.user not in Project.Users.all() or request.user.is_anonymous))
    if request.user not in Project.Users.all() or request.user.is_anonymous:
        return render(request, 'app/Project.html', {'project': Project})
    elif request.user in Project.Users.all():
        if request.method == 'POST':
            form = CreateTask(request.POST)
            if form.is_valid():
                Task.objects.create(**form.cleaned_data, ProjectRel=Project, Done= False)
                return redirect(request.META.get('HTTP_REFERER'))

        else:
            form = CreateTask()
            tasks = Task.objects.filter(ProjectRel=Project)
            context={
                'project':Project,
                'taskform': form,
                'tasks':tasks
            }
            return render(request, 'app/ProjectDo.html', context)


def ChangeProject(request, ProjectId):
    Project = md.Project.objects.get(id=ProjectId)
    initial={
        'ProjectName':Project.ProjectName,
        'Summury':Project.Summury,
        'Content':Project.Content,
        'Subject':Project.Subject,
        'Users':' '.join(UserList(Project))
    }
    if request.method == 'POST':
            
        form=CreateProject(request.POST, initial=initial)
        if form.is_valid():
            Project.ProjectName = form.cleaned_data['ProjectName']
            Project.Summury = form.cleaned_data['Summury']
            Project.Content = form.cleaned_data['Content']
            Project.save()
            Project.Users.clear()
            for user in form.cleaned_data['Users'].split():
                Project.Users.add(User.objects.get(username=user))
            return redirect(request.META.get('HTTP_REFERER'))
    else:
        form=CreateProject(initial=initial)
        return render(request, 'app/ChangeProject.html', {'form':form, 'project':Project})


def MyProjects(request):
    Projects = Project.objects.filter(Users=request.user)
    Done = Projects.filter(Status='done')
    Processing = Projects.filter(Status='processing')
    context={
        'Done':Done,
        'Processing':Processing,
    }
    return render(request, 'app/MyProjects.html', context)

def ApplyProject(request, ProjectId):
    Project = md.Project.objects.get(pk=ProjectId)
    Project.Users.add(request.user)
    Project.Status = 'processing'
    Project.save()
    return redirect(request.META.get('HTTP_REFERER'))


def TaskDone(request, TaskId):
    Task = md.Task.objects.get(pk= TaskId)
    Task.Done = True
    Task.save()
    return redirect(request.META.get('HTTP_REFERER'))

def CancelProject(request, ProjectId):
    Project = md.Project.objects.get(pk=ProjectId)
    Project.Users.clear()
    Project.Status='published'
    Project.save()
    Task.objects.filter(ProjectRel=Project).delete()
    return redirect(request.META.get('HTTP_REFERER'))

def ClearTasks(request, ProjectId):
    Project = md.Project.objects.get(pk=ProjectId)
    Task.objects.filter(ProjectRel=Project).delete()
    return redirect(request.META.get('HTTP_REFERER'))

def ProjectDone(request, ProjectId):
    Project = md.Project.objects.get(pk=ProjectId)
    Project.Status = 'done'
    Project.save()
    print(Project)
    return redirect(request.META.get('HTTP_REFERER'))

def ProjectResume(request, ProjectId):
    Project = md.Project.objects.get(pk=ProjectId)
    Project.Status = 'processing'
    Project.save()
    print(Project)
    return redirect(request.META.get('HTTP_REFERER'))

